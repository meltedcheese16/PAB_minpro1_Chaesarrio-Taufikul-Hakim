package com.example.wakeupsosial

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
