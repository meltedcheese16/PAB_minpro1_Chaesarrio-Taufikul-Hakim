import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class Coffee {
  String name;
  String type;
  String price;
  String? description; // Tambahan opsional

  Coffee({
    required this.name,
    required this.type,
    required this.price,
    this.description,
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Katalog Kopi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.brown,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Coffee> coffeeList = [];
  
  final nameController = TextEditingController();
  final typeController = TextEditingController();
  final priceController = TextEditingController();
  final descController = TextEditingController(); // Tambahan

  final Color coffeeDark = const Color(0xFF4E342E);
  final Color coffeeMedium = const Color(0xFF8D6E63);
  final Color coffeeLight = const Color(0xFFD7CCC8);
  final Color coffeeCream = const Color(0xFFFFF8E1);

  IconData getCoffeeIcon(String type) {
    String t = type.toLowerCase();
    if (t.contains('arabica')) return Icons.coffee;
    if (t.contains('robusta')) return Icons.local_cafe;
    if (t.contains('blend')) return Icons.coffee_maker;
    return Icons.free_breakfast;
  }

  Color getTypeColor(String type) {
    String t = type.toLowerCase();
    if (t.contains('arabica')) return Colors.green;
    if (t.contains('robusta')) return Colors.red;
    if (t.contains('blend')) return Colors.orange;
    return Colors.brown;
  }

  // 🆕 FITUR Tampilkan detail kopi
  void showCoffeeDetail(Coffee coffee, int index) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.white, coffeeCream],
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon besar
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: getTypeColor(coffee.type).withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  getCoffeeIcon(coffee.type),
                  size: 40,
                  color: getTypeColor(coffee.type),
                ),
              ),
              const SizedBox(height: 16),
              
              // Nama kopi
              Text(
                coffee.name,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: coffeeDark,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              
              // Badge jenis
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: getTypeColor(coffee.type).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  coffee.type.toUpperCase(),
                  style: TextStyle(
                    color: getTypeColor(coffee.type),
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              
              // Harga besar
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: coffeeMedium.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Text(
                      'HARGA',
                      style: TextStyle(
                        fontSize: 12,
                        color: coffeeMedium,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Rp ${coffee.price}',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: coffeeDark,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              
              // Tombol tutup
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: coffeeMedium,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Tutup',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void addCoffee() {
    if (nameController.text.isEmpty ||
        typeController.text.isEmpty ||
        priceController.text.isEmpty) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Row(
            children: [
              Icon(Icons.error, color: Colors.red),
              SizedBox(width: 8),
              Text('Oops!'),
            ],
          ),
          content: const Text('Semua field harus diisi ya! ☕'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }

    setState(() {
      coffeeList.add(Coffee(
        name: nameController.text,
        type: typeController.text,
        price: priceController.text,
        description: descController.text.isEmpty ? null : descController.text,
      ));
    });

    nameController.clear();
    typeController.clear();
    priceController.clear();
    descController.clear();
    Navigator.pop(context);
    
    // Tambahan: Snackbar notifikasi
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.white),
            SizedBox(width: 8),
            Text('Kopi berhasil ditambahkan!'),
          ],
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  void deleteCoffee(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: const Text(
          'Hapus Kopi?',
          style: TextStyle(color: Colors.brown, fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Yakin ingin menghapus "${coffeeList[index].name}"?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                coffeeList.removeAt(index);
              });
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  void showAddDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Row(
          children: [
            Icon(Icons.add_circle, color: coffeeMedium),
            const SizedBox(width: 8),
            const Text(
              'Tambah Kopi',
              style: TextStyle(
                color: Colors.brown,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Nama Kopi',
                  hintText: 'Contoh: Kopi Susu Gula Aren',
                  prefixIcon: const Icon(Icons.coffee, color: Colors.brown),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(color: Colors.brown, width: 2),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              
              TextField(
                controller: typeController,
                decoration: InputDecoration(
                  labelText: 'Jenis Kopi',
                  hintText: 'Arabica / Robusta / Blend',
                  prefixIcon: const Icon(Icons.category, color: Colors.brown),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(color: Colors.brown, width: 2),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              
              TextField(
                controller: priceController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Harga',
                  hintText: 'Contoh: 25000',
                  prefixIcon: const Icon(Icons.attach_money, color: Colors.brown),
                  prefixText: 'Rp ',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(color: Colors.brown, width: 2),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: addCoffee,
            style: ElevatedButton.styleFrom(
              backgroundColor: coffeeMedium,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: coffeeCream,
      appBar: AppBar(
        title: const Text(
          '☕ Katalog Kopi @Wakeup.social',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [coffeeDark, coffeeMedium],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        elevation: 4,
      ),
      body: coffeeList.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.local_cafe_outlined,
                    size: 100,
                    color: coffeeMedium.withOpacity(0.5),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Belum ada kopi nih!',
                    style: TextStyle(
                      fontSize: 20,
                      color: coffeeDark,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Tap tombol + di bawah untuk menambahkan',
                    style: TextStyle(
                      fontSize: 14,
                      color: coffeeMedium,
                    ),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: coffeeList.length,
              itemBuilder: (context, index) {
                return Card(
                  elevation: 4,
                  shadowColor: Colors.brown.withOpacity(0.3),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  margin: const EdgeInsets.only(bottom: 12),
                  child: InkWell(
                    //  FITUR Klik untuk detail
                    onTap: () => showCoffeeDetail(coffeeList[index], index),
                    borderRadius: BorderRadius.circular(15),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        gradient: LinearGradient(
                          colors: [Colors.white, coffeeLight.withOpacity(0.3)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        leading: Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: getTypeColor(coffeeList[index].type)
                                .withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            getCoffeeIcon(coffeeList[index].type),
                            color: getTypeColor(coffeeList[index].type),
                            size: 28,
                          ),
                        ),
                        title: Text(
                          coffeeList[index].name,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: coffeeDark,
                          ),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: getTypeColor(coffeeList[index].type)
                                      .withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: getTypeColor(coffeeList[index].type)
                                        .withOpacity(0.3),
                                  ),
                                ),
                                child: Text(
                                  coffeeList[index].type,
                                  style: TextStyle(
                                    color: getTypeColor(coffeeList[index].type),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                '• Rp ${coffeeList[index].price}',
                                style: TextStyle(
                                  color: coffeeMedium,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Indikator bisa diklik
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.touch_app,
                              size: 16,
                              color: coffeeMedium.withOpacity(0.5),
                            ),
                            const SizedBox(width: 4),
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.red.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: IconButton(
                                icon: const Icon(Icons.delete_outline),
                                color: Colors.red,
                                onPressed: () => deleteCoffee(index),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [coffeeMedium, coffeeDark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: coffeeDark.withOpacity(0.4),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FloatingActionButton.extended(
          onPressed: showAddDialog,
          backgroundColor: Colors.transparent,
          elevation: 0,
          icon: const Icon(Icons.add),
          label: const Text(
            'Tambah Kopi',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    typeController.dispose();
    priceController.dispose();
    descController.dispose();
    super.dispose();
  }
}